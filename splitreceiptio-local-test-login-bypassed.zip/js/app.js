/**
 * app.js — Main application logic for Ledger Receipt Tracker
 * 
 * Handles:
 * - Page navigation
 * - Upload flow + AI/mock scanning
 * - Review screen (confirm/edit categories)
 * - Dashboard rendering + donut chart
 * - Receipt history
 * - Month filtering
 */

// ═══════════════════════════════════════
// STATE
// ═══════════════════════════════════════

let currentReceiptDraft = null; // Receipt being reviewed, not yet saved
let selectedFile = null;        // Uploaded image file

// ═══════════════════════════════════════
// NAVIGATION
// ═══════════════════════════════════════

function showPage(pageId) {
  document.querySelectorAll('.page').forEach(p => p.classList.remove('active'));
  document.querySelectorAll('.nav-item').forEach(n => n.classList.remove('active'));

  const page = document.getElementById(`page-${pageId}`);
  if (page) page.classList.add('active');

  const navItem = document.querySelector(`[data-page="${pageId}"]`);
  if (navItem) navItem.classList.add('active');

  // Refresh page content on navigation
  if (pageId === 'dashboard') renderDashboard();
  if (pageId === 'history') renderHistoryPage();
  if (pageId === 'upload') resetUploadPage();

  // Close mobile sidebar
  closeSidebar();
}

function toggleSidebar() {
  const sidebar = document.getElementById('sidebar');
  const overlay = document.getElementById('sidebarOverlay');
  sidebar.classList.toggle('open');
  overlay.classList.toggle('open');
}
function closeSidebar() {
  document.getElementById('sidebar').classList.remove('open');
  document.getElementById('sidebarOverlay').classList.remove('open');
}

// ═══════════════════════════════════════
// MONTH FILTER HELPERS
// ═══════════════════════════════════════

function getAvailableMonths() {
  const receipts = loadReceipts();
  const months = new Set(receipts.map(r => r.date.slice(0, 7)));
  const today = new Date();
  // Always include current month
  months.add(`${today.getFullYear()}-${String(today.getMonth() + 1).padStart(2, '0')}`);
  return Array.from(months).sort().reverse();
}

function getCurrentMonthKey() {
  const today = new Date();
  return `${today.getFullYear()}-${String(today.getMonth() + 1).padStart(2, '0')}`;
}

function populateMonthFilter(selectId, selectedMonth) {
  const select = document.getElementById(selectId);
  if (!select) return;
  const months = getAvailableMonths();
  const current = selectedMonth || getCurrentMonthKey();
  select.innerHTML = months.map(m => {
    const [y, mo] = m.split('-');
    const label = new Date(+y, +mo - 1, 1).toLocaleDateString('en-US', { month: 'long', year: 'numeric' });
    return `<option value="${m}" ${m === current ? 'selected' : ''}>${label}</option>`;
  }).join('');
}

function filterByMonth() {
  renderDashboard();
}

function getFilteredReceipts(selectId) {
  const select = document.getElementById(selectId);
  const monthKey = select ? select.value : getCurrentMonthKey();
  return loadReceipts().filter(r => r.date.startsWith(monthKey));
}

// ═══════════════════════════════════════
// DASHBOARD
// ═══════════════════════════════════════

function renderDashboard() {
  populateMonthFilter('monthFilter');
  const receipts = getFilteredReceipts('monthFilter');
  const monthKey = document.getElementById('monthFilter')?.value || getCurrentMonthKey();
  const [y, mo] = monthKey.split('-');
  const monthLabel = new Date(+y, +mo - 1, 1).toLocaleDateString('en-US', { month: 'long', year: 'numeric' });
  document.getElementById('dashboard-month-label').textContent = monthLabel;

  // Category totals
  const catTotals = buildCategoryTotals(receipts);
  const sorted = Object.entries(catTotals).sort((a, b) => b[1] - a[1]);

  // Summary
  // Use the categorized item total for the dashboard/chart so the donut always adds up to 100%.
  // Receipt totals can include tax/fees/rounding that are not assigned to a category.
  const total = sorted.reduce((sum, [, amt]) => sum + amt, 0);
  const avg = receipts.length ? total / receipts.length : 0;
  document.getElementById('totalSpent').textContent = formatCurrency(total);
  document.getElementById('receiptCount').textContent = `${receipts.length} receipt${receipts.length !== 1 ? 's' : ''}`;
  document.getElementById('avgReceipt').textContent = formatCurrency(avg);

  if (sorted.length > 0) {
    const [topCatId, topAmt] = sorted[0];
    const topCat = getCategoryById(topCatId);
    document.getElementById('topCategory').textContent = topCat.label;
    document.getElementById('topCategoryAmt').textContent = formatCurrency(topAmt);
  } else {
    document.getElementById('topCategory').textContent = '—';
    document.getElementById('topCategoryAmt').textContent = '$0.00';
  }

  renderCategoryList(sorted, total);
  renderDonutChart(sorted, total);
  renderRecentReceipts(receipts.slice().reverse().slice(0, 5));
}

function buildCategoryTotals(receipts) {
  const totals = {};
  receipts.forEach(r => {
    (r.items || []).forEach(item => {
      totals[item.category] = (totals[item.category] || 0) + item.price;
    });
  });
  return totals;
}

function renderCategoryList(sorted, total) {
  const container = document.getElementById('categoryList');
  if (sorted.length === 0) {
    container.innerHTML = `<div class="empty-state"><p>No data yet. Upload your first receipt!</p><button class="btn-primary" onclick="showPage('upload')">Upload Receipt</button></div>`;
    return;
  }
  container.innerHTML = sorted.map(([catId, amt]) => {
    const cat = getCategoryById(catId);
    const pct = total > 0 ? (amt / total * 100).toFixed(1) : 0;
    return `
      <div class="category-row">
        <div class="cat-row-left">
          <div class="cat-dot" style="background:${cat.color}"></div>
          <span class="cat-row-name">${cat.label}</span>
          <span class="cat-row-pct">${pct}%</span>
        </div>
        <span class="cat-row-amt">${formatCurrency(amt)}</span>
      </div>
      <div class="cat-progress-bar">
        <div class="cat-progress-fill" style="width:${pct}%;background:${cat.color}"></div>
      </div>
    `;
  }).join('');
}

function renderRecentReceipts(receipts) {
  const container = document.getElementById('recentReceiptsList');
  if (receipts.length === 0) {
    container.innerHTML = `<div class="empty-state"><p>No receipts added yet.</p></div>`;
    return;
  }
  container.innerHTML = receipts.map(r => `
    <div class="receipt-row">
      <div class="receipt-row-left">
        <div class="receipt-store-icon">🧾</div>
        <div>
          <div class="receipt-store">${escapeHtml(r.store)}</div>
          <div class="receipt-date">${formatDate(r.date)}</div>
        </div>
      </div>
      <div>
        <div class="receipt-amt">${formatCurrency(r.total)}</div>
        <div class="receipt-item-count">${r.items?.length || 0} items</div>
      </div>
    </div>
  `).join('');
}

// ═══════════════════════════════════════
// DONUT CHART (Canvas-based, no library)
// ═══════════════════════════════════════

function renderDonutChart(sorted, total) {
  const canvas = document.getElementById('donutChart');
  const empty = document.getElementById('chartEmpty');
  const legend = document.getElementById('chartLegend');

  if (sorted.length === 0 || total === 0) {
    canvas.style.display = 'none';
    empty.style.display = 'block';
    legend.innerHTML = '';
    return;
  }

  canvas.style.display = 'block';
  empty.style.display = 'none';

  const ctx = canvas.getContext('2d');
  const cx = 130, cy = 130, r = 100, inner = 60;
  const TAU = Math.PI * 2;
  ctx.clearRect(0, 0, 260, 260);

  let startAngle = -Math.PI / 2;

  // Draw each slice immediately and then advance the start angle.
  // The old code built every slice with the same startAngle, which caused overlapping arcs.
  sorted.forEach(([catId, amt]) => {
    const cat = getCategoryById(catId);
    const slice = (amt / total) * TAU;

    ctx.beginPath();
    ctx.moveTo(cx, cy);
    ctx.arc(cx, cy, r, startAngle, startAngle + slice);
    ctx.closePath();
    ctx.fillStyle = cat.color;
    ctx.fill();

    startAngle += slice;
  });

  // Inner cutout (donut hole)
  ctx.beginPath();
  ctx.arc(cx, cy, inner, 0, TAU);
  ctx.fillStyle = getComputedStyle(document.body).getPropertyValue('--surface').trim() || '#fff';
  ctx.fill();

  // Center text
  ctx.textAlign = 'center';
  ctx.fillStyle = '#1C1C1E';
  ctx.font = '600 16px DM Mono, monospace';
  ctx.fillText(formatCurrency(total), cx, cy + 4);
  ctx.font = '400 11px DM Sans, sans-serif';
  ctx.fillStyle = '#A09C96';
  ctx.fillText('total', cx, cy + 18);

  // Legend
  legend.innerHTML = sorted.slice(0, 6).map(([catId]) => {
    const cat = getCategoryById(catId);
    return `<div class="legend-item"><div class="legend-dot" style="background:${cat.color}"></div>${cat.label}</div>`;
  }).join('');
}

// ═══════════════════════════════════════
// UPLOAD PAGE
// ═══════════════════════════════════════

function resetUploadPage() {
  selectedFile = null;
  document.getElementById('fileInput').value = '';
  document.getElementById('uploadZoneContent').style.display = 'block';
  document.getElementById('uploadPreview').style.display = 'none';
  document.getElementById('uploadActions').style.display = 'flex';
  document.getElementById('processingState').style.display = 'none';
  document.getElementById('scanBtn').disabled = true;
}

function handleDragOver(e) {
  e.preventDefault();
  document.getElementById('uploadZone').classList.add('drag-over');
}
function handleDragLeave() {
  document.getElementById('uploadZone').classList.remove('drag-over');
}
function handleDrop(e) {
  e.preventDefault();
  document.getElementById('uploadZone').classList.remove('drag-over');
  const file = e.dataTransfer.files[0];
  if (file && file.type.startsWith('image/')) {
    setUploadedFile(file);
  } else {
    showToast('Please upload an image file', 'error');
  }
}

function handleFileSelect(e) {
  const file = e.target.files[0];
  if (file) setUploadedFile(file);
}

function setUploadedFile(file) {
  selectedFile = file;
  const reader = new FileReader();
  reader.onload = (e) => {
    document.getElementById('previewImg').src = e.target.result;
    document.getElementById('uploadZoneContent').style.display = 'none';
    document.getElementById('uploadPreview').style.display = 'block';
    document.getElementById('scanBtn').disabled = false;
  };
  reader.readAsDataURL(file);
}

function removeImage(e) {
  e.stopPropagation();
  resetUploadPage();
}

async function scanReceipt() {
  if (!selectedFile) return;

  // Show processing UI
  document.getElementById('uploadActions').style.display = 'none';
  document.getElementById('processingState').style.display = 'block';

  // Cycle through step labels
  let stepIdx = 0;
  const stepEl = document.getElementById('processingStep');
  const stepInterval = setInterval(() => {
    stepEl.textContent = SCAN_STEPS[Math.min(stepIdx++, SCAN_STEPS.length - 1)];
  }, 900);

  try {
    // ──────────────────────────────────────────────
    // REAL AI PARSING via Anthropic Vision API
    // Sends the image to Claude for OCR + categorization.
    // Falls back to mock data if the API call fails.
    // ──────────────────────────────────────────────
    let receiptData;
    try {
      receiptData = await parseReceiptWithAI(selectedFile);
    } catch (aiErr) {
      console.warn('AI parsing failed, using mock data:', aiErr);
      showToast('Using demo data (AI unavailable)', 'info');
      receiptData = parseMockReceipt();
      receiptData.isDemo = true;
    }

    clearInterval(stepInterval);
    currentReceiptDraft = receiptData;
    showReviewPage(receiptData);

  } catch (err) {
    clearInterval(stepInterval);
    console.error('Scan error:', err);
    showToast('Could not scan receipt. Try a clearer photo.', 'error');
    document.getElementById('uploadActions').style.display = 'flex';
    document.getElementById('processingState').style.display = 'none';
  }
}

function loadSampleReceipt() {
  // Show a brief processing animation for UX realism
  document.getElementById('uploadActions').style.display = 'none';
  document.getElementById('processingState').style.display = 'block';
  document.getElementById('uploadZoneContent').style.display = 'block';
  document.getElementById('uploadPreview').style.display = 'none';

  let stepIdx = 0;
  const stepEl = document.getElementById('processingStep');
  const stepInterval = setInterval(() => {
    stepEl.textContent = SCAN_STEPS[Math.min(stepIdx++, SCAN_STEPS.length - 1)];
  }, 500);

  setTimeout(() => {
    clearInterval(stepInterval);
    currentReceiptDraft = parseMockReceipt();
    currentReceiptDraft.isDemo = true;
    showReviewPage(currentReceiptDraft);
  }, 2200);
}

// ═══════════════════════════════════════
// REVIEW PAGE
// ═══════════════════════════════════════

function showReviewPage(receipt) {
  showPage('review');

  // Populate meta
  document.getElementById('metaStore').textContent = receipt.store || '—';
  document.getElementById('metaDate').textContent = formatDate(receipt.date);
  document.getElementById('metaTotal').textContent = formatCurrency(receipt.total);
  document.getElementById('metaItemCount').textContent = receipt.items.length;
  document.getElementById('reviewSubtitle').textContent = receipt.isDemo
    ? `${receipt.items.length} demo items found — preview only, not saved to your real budget`
    : `${receipt.items.length} items found — confirm or adjust categories`;

  const saveBtn = document.getElementById('saveReceiptBtn');
  if (saveBtn) {
    saveBtn.textContent = receipt.isDemo ? 'Demo Only — Not Saved' : 'Save Receipt';
    saveBtn.title = receipt.isDemo ? 'Demo receipts are previews and do not affect your real budget.' : '';
  }

  // Build items list
  renderItemsList(receipt.items);
  updateConfirmedCount(receipt.items);
}

function renderItemsList(items) {
  const container = document.getElementById('itemsList');
  const categoryOptions = CATEGORIES.map(c =>
    `<option value="${c.id}">${c.emoji} ${c.label}</option>`
  ).join('');

  container.innerHTML = items.map((item, idx) => {
    const cat = getCategoryById(item.category);
    return `
      <div class="item-row" id="item-row-${idx}" data-confirmed="false">
        <button class="item-check" id="check-${idx}" onclick="toggleConfirm(${idx})" title="Confirm item">
          ✓
        </button>
        <span class="item-name">${escapeHtml(item.name)}</span>
        <span class="item-price">${formatCurrency(item.price)}</span>
        <select class="cat-select" id="cat-${idx}"
          onchange="updateItemCategory(${idx}, this.value)"
          style="border-color: ${cat.color}20; background-color: ${cat.color}12; color: ${cat.color};"
        >
          ${CATEGORIES.map(c =>
            `<option value="${c.id}" ${c.id === item.category ? 'selected' : ''}>${c.emoji} ${c.label}</option>`
          ).join('')}
        </select>
      </div>
    `;
  }).join('');
}

function updateItemCategory(idx, newCatId) {
  if (!currentReceiptDraft) return;
  currentReceiptDraft.items[idx].category = newCatId;

  const cat = getCategoryById(newCatId);
  const select = document.getElementById(`cat-${idx}`);
  select.style.borderColor = `${cat.color}30`;
  select.style.backgroundColor = `${cat.color}14`;
  select.style.color = cat.color;
}

function toggleConfirm(idx) {
  const row = document.getElementById(`item-row-${idx}`);
  const btn = document.getElementById(`check-${idx}`);
  const isConfirmed = row.dataset.confirmed === 'true';

  row.dataset.confirmed = !isConfirmed;
  row.classList.toggle('confirmed', !isConfirmed);
  btn.classList.toggle('checked', !isConfirmed);

  updateConfirmedCount(currentReceiptDraft?.items || []);
}

function confirmAll() {
  const items = currentReceiptDraft?.items || [];
  items.forEach((_, idx) => {
    const row = document.getElementById(`item-row-${idx}`);
    const btn = document.getElementById(`check-${idx}`);
    if (row) { row.dataset.confirmed = 'true'; row.classList.add('confirmed'); }
    if (btn) btn.classList.add('checked');
  });
  updateConfirmedCount(items);
}

function updateConfirmedCount(items) {
  const total = items.length;
  const confirmed = document.querySelectorAll('[data-confirmed="true"]').length;
  document.getElementById('confirmedCount').textContent = currentReceiptDraft?.isDemo
    ? `${confirmed} of ${total} confirmed — demo preview only`
    : `${confirmed} of ${total} confirmed`;

  const saveBtn = document.getElementById('saveReceiptBtn');
  if (saveBtn) {
    saveBtn.disabled = currentReceiptDraft?.isDemo || confirmed === 0;
    saveBtn.textContent = currentReceiptDraft?.isDemo ? 'Demo Only — Not Saved' : 'Save Receipt';
  }
}

function saveReceipt() {
  if (!currentReceiptDraft) return;

  if (currentReceiptDraft.isDemo) {
    showToast('Demo receipts are previews and are not saved to your real budget.', 'info');
    showPage('upload');
    return;
  }

  const receipt = {
    ...currentReceiptDraft,
    id: `receipt-${Date.now()}`,
    savedAt: new Date().toISOString(),
  };

  addReceipt(receipt);
  currentReceiptDraft = null;
  showToast(`Receipt from ${receipt.store} saved!`, 'success');
  showPage('dashboard');
}


// ═══════════════════════════════════════
// HISTORY PAGE
// ═══════════════════════════════════════

let currentHistoryTab = 'active';

function switchHistoryTab(tab) {
  currentHistoryTab = tab;
  document.getElementById('tab-active').classList.toggle('active', tab === 'active');
  document.getElementById('tab-trash').classList.toggle('active', tab === 'trash');
  document.getElementById('historyList').style.display  = tab === 'active' ? 'block' : 'none';
  document.getElementById('trashList').style.display    = tab === 'trash'  ? 'block' : 'none';
  document.getElementById('historyMonthFilter').style.visibility = tab === 'active' ? 'visible' : 'hidden';
  if (tab === 'trash') renderTrashList();
  else renderHistoryPage();
}

function renderHistoryPage() {
  populateMonthFilter('historyMonthFilter');
  updateTrashBadge();
  const receipts = getFilteredReceipts('historyMonthFilter').slice().reverse();
  const container = document.getElementById('historyList');

  if (receipts.length === 0) {
    container.innerHTML = `
      <div class="empty-state card">
        <span class="empty-icon">🧾</span>
        <p>No receipts for this month.</p>
        <button class="btn-primary" onclick="showPage('upload')">Upload a receipt</button>
      </div>
    `;
    return;
  }
  container.innerHTML = receipts.map(r => buildReceiptCard(r, false)).join('');
}

function renderTrashList() {
  updateTrashBadge();
  const trash = loadTrash().slice().reverse();
  const container = document.getElementById('trashList');

  if (trash.length === 0) {
    container.innerHTML = `
      <div class="empty-state card">
        <span class="empty-icon">🗑</span>
        <p>No deleted receipts.</p>
        <p style="font-size:12px;margin-top:4px;">Deleted receipts appear here for 30 days.</p>
      </div>
    `;
    return;
  }

  container.innerHTML = `
    <div class="trash-empty-actions">
      <button class="btn-empty-trash" onclick="confirmEmptyTrash()">Empty Trash (${trash.length})</button>
    </div>
    ${trash.map(r => buildReceiptCard(r, true)).join('')}
  `;
}

function buildReceiptCard(r, isTrashed) {
  const catGroups = {};
  (r.items || []).forEach(item => {
    catGroups[item.category] = (catGroups[item.category] || 0) + item.price;
  });

  const catPills = Object.entries(catGroups)
    .sort((a, b) => b[1] - a[1])
    .map(([catId, amt]) => {
      const cat = getCategoryById(catId);
      return `<span class="history-cat-pill" style="background:${cat.color}18;color:${cat.color};">${cat.emoji} ${cat.label} ${formatCurrency(amt)}</span>`;
    }).join('');

  const itemRows = (r.items || []).map(item => {
    const cat = getCategoryById(item.category);
    return `
      <div class="history-item-row">
        <span class="history-item-name">${escapeHtml(item.name)}</span>
        <div class="history-item-right">
          <span class="cat-badge" style="background:${cat.color}18;color:${cat.color};">${cat.label}</span>
          <span class="history-item-price">${formatCurrency(item.price)}</span>
        </div>
      </div>
    `;
  }).join('');

  let trashInfo = '';
  if (isTrashed && r.deletedAt) {
    const daysLeft = Math.ceil((new Date(r.deletedAt).getTime() + 30 * 864e5 - Date.now()) / 864e5);
    trashInfo = `<div class="trash-expiry">Deleted ${formatDate(r.deletedAt.split('T')[0])} · auto-removes in ${daysLeft} day${daysLeft !== 1 ? 's' : ''}</div>`;
  }

  const actions = isTrashed
    ? `<div class="history-card-actions">
        <button class="btn-restore"     onclick="handleRestore('${r.id}')">↩ Restore</button>
        <button class="btn-perm-delete" onclick="handlePermDelete('${r.id}')">Delete Forever</button>
       </div>`
    : `<div class="history-card-actions">
        <div class="history-total">${formatCurrency(r.total)}</div>
        <button class="btn-delete" onclick="handleDelete('${r.id}')">🗑 Delete</button>
       </div>`;

  return `
    <div class="card history-receipt-card ${isTrashed ? 'trashed' : ''}">
      <div class="history-card-header">
        <div class="history-store-info">
          <div class="history-store-icon">🧾</div>
          <div>
            <div class="history-store-name">${escapeHtml(r.store)}</div>
            <div class="history-store-date">${formatDate(r.date)} · ${r.items?.length || 0} items</div>
            ${trashInfo}
          </div>
        </div>
        ${actions}
      </div>
      <div class="history-items">${itemRows}</div>
      <div class="history-cat-summary">${catPills}</div>
    </div>
  `;
}

function handleDelete(receiptId) {
  if (!confirm('Move this receipt to Recently Deleted? You can restore it within 30 days.')) return;
  moveToTrash(receiptId);
  showToast('Receipt moved to trash', '');
  renderHistoryPage();
  renderDashboard();
}

function handleRestore(receiptId) {
  restoreFromTrash(receiptId);
  showToast('Receipt restored', 'success');
  renderTrashList();
  renderDashboard();
}

function handlePermDelete(receiptId) {
  if (!confirm('Permanently delete this receipt? This cannot be undone.')) return;
  permanentlyDelete(receiptId);
  showToast('Receipt permanently deleted', '');
  renderTrashList();
}

function confirmEmptyTrash() {
  if (!confirm('Permanently delete all receipts in trash? This cannot be undone.')) return;
  emptyTrash();
  showToast('Trash emptied', '');
  renderTrashList();
}

function updateTrashBadge() {
  const trash = loadTrash();
  const badge = document.getElementById('trashBadge');
  if (!badge) return;
  if (trash.length > 0) {
    badge.textContent = trash.length;
    badge.style.display = 'inline-flex';
  } else {
    badge.style.display = 'none';
  }
}

// ═══════════════════════════════════════
// TOAST NOTIFICATIONS
// ═══════════════════════════════════════

function showToast(message, type = '') {
  const container = document.getElementById('toastContainer');
  const toast = document.createElement('div');
  toast.className = `toast ${type ? 'toast--' + type : ''}`;
  toast.textContent = message;
  container.appendChild(toast);
  setTimeout(() => {
    toast.style.opacity = '0';
    toast.style.transition = 'opacity 0.3s';
    setTimeout(() => toast.remove(), 300);
  }, 3000);
}

// ═══════════════════════════════════════
// UTILITIES
// ═══════════════════════════════════════

function formatCurrency(amount) {
  return new Intl.NumberFormat('en-US', { style: 'currency', currency: 'USD' }).format(amount || 0);
}

function formatDate(dateStr) {
  if (!dateStr) return '—';
  const [y, m, d] = dateStr.split('-');
  return new Date(+y, +m - 1, +d).toLocaleDateString('en-US', { month: 'short', day: 'numeric', year: 'numeric' });
}

function escapeHtml(str) {
  const div = document.createElement('div');
  div.appendChild(document.createTextNode(str || ''));
  return div.innerHTML;
}

// ═══════════════════════════════════════
// INIT
// ═══════════════════════════════════════

document.addEventListener('DOMContentLoaded', () => {
  // auth.js calls renderDashboard() once the user is confirmed logged in.
  // initAuth() is defined in auth.js (loaded after this file).
  initAuth();
});
