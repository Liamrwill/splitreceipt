/**
 * local-auth-bypass.js — Local testing only
 *
 * This bypasses Netlify Identity so the app can be opened locally with index.html.
 * Do NOT deploy this version as your real production app.
 */

const LOCAL_TEST_USER = {
  id: 'local-test-user',
  email: 'localtest@splitreceiptio.local',
  user_metadata: { full_name: 'Local Test' }
};

function updateSidebarUserLocal(user) {
  const displayName = user?.user_metadata?.full_name || user?.email || 'Local Test';
  const initials = displayName.charAt(0).toUpperCase();

  const nameEl = document.getElementById('userName');
  const emailEl = document.getElementById('userEmail');
  const avatarEl = document.getElementById('userAvatar');

  if (nameEl) nameEl.textContent = displayName;
  if (emailEl) emailEl.textContent = 'Local testing mode';
  if (avatarEl) avatarEl.textContent = initials;
}

function initAuth() {
  setCurrentUser(LOCAL_TEST_USER);
  document.body.classList.remove('auth-required');
  updateSidebarUserLocal(LOCAL_TEST_USER);
  renderDashboard();
  showToast('Local test mode: login is bypassed.', 'info');
}

function handleLogout() {
  showToast('Local test mode: sign out is disabled.', 'info');
}

function switchAuthTab() {}
function handleLogin(e) { if (e) e.preventDefault(); initAuth(); }
function handleSignup(e) { if (e) e.preventDefault(); initAuth(); }
function handleForgotPassword(e) { if (e) e.preventDefault(); }
function showForgotPassword() {}
