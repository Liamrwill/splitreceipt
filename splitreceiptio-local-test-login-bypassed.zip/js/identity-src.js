/**
 * identity-src.js — Entry point for esbuild
 *
 * Bundles @netlify/identity into a browser-ready IIFE exposed as window.NetlifyIdentity.
 * Built during Netlify deploy via: npm run build:identity
 * Output: js/identity.js (generated — not committed to git)
 */
export {
  login,
  logout,
  signup,
  getUser,
  isAuthenticated,
  onAuthChange,
  handleAuthCallback,
  requestPasswordRecovery,
  updateUser,
  AUTH_EVENTS,
  AuthError,
  MissingIdentityError,
} from '@netlify/identity';
