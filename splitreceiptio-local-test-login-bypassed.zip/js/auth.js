/**
 * auth.js — Netlify Identity integration for Ledger
 *
 * Uses the NetlifyIdentity global (bundled from @netlify/identity into js/identity.js at build time).
 * Handles login, signup, logout, password recovery, and email confirmation callbacks.
 *
 * Storage note: Receipt data lives in localStorage, which is browser/device-specific.
 * Each user gets isolated storage keys (ledger_receipts_<userId>) so accounts don't
 * share data on the same device.
 *
 * TODO: For cross-device syncing, migrate receipt data from localStorage to a real
 * database such as Netlify Database (Postgres) or Supabase. localStorage is a temporary
 * solution — users will lose their data if they clear browser storage or switch devices.
 */

// ─── Destructure from the bundle global ───────────────────────────────────────
const {
  login,
  logout,
  signup,
  getUser,
  onAuthChange,
  handleAuthCallback,
  requestPasswordRecovery,
  AUTH_EVENTS,
  AuthError,
  MissingIdentityError,
} = NetlifyIdentity;

// ─── Internal state ───────────────────────────────────────────────────────────
let currentAuthTab = 'login'; // 'login' | 'signup' | 'forgot'

// ─── Show / hide app ──────────────────────────────────────────────────────────

function showApp(user) {
  setCurrentUser(user);
  document.body.classList.remove('auth-required');
  updateSidebarUser(user);
  renderDashboard();
}

function showAuthScreen() {
  setCurrentUser(null);
  document.body.classList.add('auth-required');
}

// ─── Sidebar user display ─────────────────────────────────────────────────────

function updateSidebarUser(user) {
  const displayName = user?.user_metadata?.full_name || user?.email || 'User';
  const initials = displayName.charAt(0).toUpperCase();

  const nameEl  = document.getElementById('userName');
  const emailEl = document.getElementById('userEmail');
  const avatarEl = document.getElementById('userAvatar');

  if (nameEl)  nameEl.textContent  = displayName;
  if (emailEl) emailEl.textContent = user?.user_metadata?.full_name ? user.email : '';
  if (avatarEl) avatarEl.textContent = initials;
}

// ─── Auth tab switching ───────────────────────────────────────────────────────

function switchAuthTab(tab) {
  currentAuthTab = tab;
  document.getElementById('loginForm').style.display   = tab === 'login'  ? '' : 'none';
  document.getElementById('signupForm').style.display  = tab === 'signup' ? '' : 'none';
  document.getElementById('forgotForm').style.display  = tab === 'forgot' ? '' : 'none';
  document.getElementById('tab-login').classList.toggle('active',  tab === 'login');
  document.getElementById('tab-signup').classList.toggle('active', tab === 'signup');
  clearAuthMessages();
}

function showForgotPassword() {
  switchAuthTab('forgot');
}

// ─── Message helpers ──────────────────────────────────────────────────────────

function clearAuthMessages() {
  const err  = document.getElementById('authError');
  const succ = document.getElementById('authSuccess');
  if (err)  { err.textContent  = ''; err.style.display  = 'none'; }
  if (succ) { succ.textContent = ''; succ.style.display = 'none'; }
}

function showAuthError(msg) {
  const err  = document.getElementById('authError');
  const succ = document.getElementById('authSuccess');
  if (err)  { err.textContent  = msg; err.style.display  = 'block'; }
  if (succ) succ.style.display = 'none';
}

function showAuthSuccess(msg) {
  const err  = document.getElementById('authError');
  const succ = document.getElementById('authSuccess');
  if (succ) { succ.textContent = msg; succ.style.display = 'block'; }
  if (err)  err.style.display = 'none';
}

// ─── Login ────────────────────────────────────────────────────────────────────

async function handleLogin(e) {
  e.preventDefault();
  clearAuthMessages();

  const email    = document.getElementById('loginEmail').value.trim();
  const password = document.getElementById('loginPassword').value;
  const btn      = document.getElementById('loginSubmit');

  btn.disabled    = true;
  btn.textContent = 'Signing in…';

  try {
    const user = await login(email, password);
    showApp(user);
  } catch (err) {
    if (err instanceof MissingIdentityError) {
      showAuthError('Identity is not enabled. Deploy this site to Netlify or run "netlify dev" locally.');
    } else if (err instanceof AuthError) {
      const msg =
        err.status === 401 ? 'Invalid email or password.' :
        err.status === 422 ? 'Please check your email and password.' :
        err.message;
      showAuthError(msg);
    } else {
      showAuthError('Something went wrong. Please try again.');
    }
  } finally {
    btn.disabled    = false;
    btn.textContent = 'Sign In';
  }
}

// ─── Signup ───────────────────────────────────────────────────────────────────

async function handleSignup(e) {
  e.preventDefault();
  clearAuthMessages();

  const name     = document.getElementById('signupName').value.trim();
  const email    = document.getElementById('signupEmail').value.trim();
  const password = document.getElementById('signupPassword').value;
  const btn      = document.getElementById('signupSubmit');

  btn.disabled    = true;
  btn.textContent = 'Creating account…';

  try {
    const user = await signup(email, password, name ? { full_name: name } : undefined);

    if (user.emailVerified) {
      // Autoconfirm is ON — user is logged in immediately
      showApp(user);
    } else {
      // Autoconfirm is OFF — confirmation email sent, not yet logged in
      showAuthSuccess('Account created! Check your email to confirm, then sign in.');
      switchAuthTab('login');
      document.getElementById('loginEmail').value = email;
    }
  } catch (err) {
    if (err instanceof MissingIdentityError) {
      showAuthError('Identity is not enabled. Deploy this site to Netlify or run "netlify dev" locally.');
    } else if (err instanceof AuthError) {
      const msg =
        err.status === 403 ? 'Signups are disabled. Contact the site admin.' :
        err.status === 422 ? 'Invalid email or password (minimum 8 characters).' :
        err.message;
      showAuthError(msg);
    } else {
      showAuthError('Something went wrong. Please try again.');
    }
  } finally {
    btn.disabled    = false;
    btn.textContent = 'Create Account';
  }
}

// ─── Forgot password ──────────────────────────────────────────────────────────

async function handleForgotPassword(e) {
  e.preventDefault();
  clearAuthMessages();

  const email = document.getElementById('forgotEmail').value.trim();
  const btn   = document.getElementById('forgotSubmit');

  btn.disabled    = true;
  btn.textContent = 'Sending…';

  try {
    await requestPasswordRecovery(email);
    showAuthSuccess('Reset link sent — check your email.');
  } catch (err) {
    showAuthError('Could not send reset email. Please try again.');
  } finally {
    btn.disabled    = false;
    btn.textContent = 'Send Reset Link';
  }
}

// ─── Logout ───────────────────────────────────────────────────────────────────

async function handleLogout() {
  try {
    await logout();
  } catch (err) {
    console.error('Logout error:', err);
  } finally {
    showAuthScreen();
    showToast('Signed out', '');
  }
}

// ─── Auth change listener ─────────────────────────────────────────────────────
// Keeps UI in sync across browser tabs.
onAuthChange((event, user) => {
  if (event === AUTH_EVENTS.LOGIN) {
    showApp(user);
  } else if (event === AUTH_EVENTS.LOGOUT) {
    showAuthScreen();
  }
});

// ─── Init ─────────────────────────────────────────────────────────────────────

async function initAuth() {
  // Process any URL hash tokens (email confirmation, password recovery, OAuth, invite)
  try {
    const result = await handleAuthCallback();
    if (result) {
      switch (result.type) {
        case 'confirmation':
          showAuthSuccess('Email confirmed! You can now sign in.');
          break;
        case 'recovery':
          // User is temporarily authenticated; let them into the app
          if (result.user) {
            showApp(result.user);
            showToast('Password recovery — you can update your password in settings.', 'info');
            return;
          }
          break;
        case 'oauth':
          if (result.user) { showApp(result.user); return; }
          break;
        case 'invite':
          showAuthSuccess('Invite link accepted! Please create your password to continue.');
          break;
        case 'email_change':
          showAuthSuccess('Email address updated successfully.');
          break;
      }
    }
  } catch (err) {
    console.warn('Auth callback error:', err);
  }

  // Check existing session
  const user = await getUser();
  if (user) {
    showApp(user);
  } else {
    showAuthScreen();
  }
}
