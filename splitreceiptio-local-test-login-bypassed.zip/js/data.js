/**
 * data.js — Sample data, storage helpers, and category config
 * 
 * This module handles:
 * - Category definitions (colors, labels)
 * - localStorage persistence
 * - Sample receipt data for demo/testing
 */

// ═══════════════════════════════════════
// CATEGORY DEFINITIONS
// ═══════════════════════════════════════

const CATEGORIES = [
  { id: 'groceries',     label: 'Groceries',       color: '#4CAF85', emoji: '🛒' },
  { id: 'eating-out',    label: 'Eating Out',       color: '#FF8C69', emoji: '🍔' },
  { id: 'coffee',        label: 'Coffee/Drinks',    color: '#C8956C', emoji: '☕' },
  { id: 'household',     label: 'Household',        color: '#6B8ED6', emoji: '🏠' },
  { id: 'personal-care', label: 'Personal Care',    color: '#D4699A', emoji: '💄' },
  { id: 'clothing',      label: 'Clothing',         color: '#9B72CF', emoji: '👕' },
  { id: 'gas',           label: 'Gas/Transport',    color: '#5BB5C8', emoji: '⛽' },
  { id: 'entertainment', label: 'Entertainment',    color: '#F5A623', emoji: '🎬' },
  { id: 'school',        label: 'School',           color: '#7BC67E', emoji: '📚' },
  { id: 'other',         label: 'Other',            color: '#A09C96', emoji: '📦' },
];

function getCategoryById(id) {
  return CATEGORIES.find(c => c.id === id) || CATEGORIES[CATEGORIES.length - 1];
}

// ═══════════════════════════════════════
// STORAGE HELPERS
// ═══════════════════════════════════════

// Storage keys are user-specific so each account has separate data on this device.
// NOTE: localStorage is browser/device-specific — data does not sync across devices.
// For cross-device syncing, migrate receipt data to a real database such as
// Netlify Database (Postgres) or Supabase, using the logged-in user's ID as the
// owner key on each row. localStorage is a temporary solution only.
const TRASH_EXPIRY_DAYS = 30;

let _currentUserId = null;

// Called by auth.js on login/logout to scope storage to the active user.
function setCurrentUser(user) {
  _currentUserId = user ? (user.id || user.email) : null;
}

function _receiptsKey() {
  return _currentUserId ? `ledger_receipts_${_currentUserId}` : 'ledger_receipts';
}

function _trashKey() {
  return _currentUserId ? `ledger_trash_${_currentUserId}` : 'ledger_trash';
}

function saveReceipts(receipts) {
  localStorage.setItem(_receiptsKey(), JSON.stringify(receipts));
}

function loadReceipts() {
  try {
    const raw = localStorage.getItem(_receiptsKey());
    return raw ? JSON.parse(raw) : [];
  } catch (e) {
    console.warn('Could not load receipts:', e);
    return [];
  }
}

function addReceipt(receipt) {
  const receipts = loadReceipts();
  receipts.push(receipt);
  saveReceipts(receipts);
  return receipts;
}

// ── TRASH (soft delete) ──────────────────

function loadTrash() {
  try {
    const raw = localStorage.getItem(_trashKey());
    const all = raw ? JSON.parse(raw) : [];
    // Auto-purge items older than 30 days
    const cutoff = Date.now() - TRASH_EXPIRY_DAYS * 24 * 60 * 60 * 1000;
    return all.filter(r => new Date(r.deletedAt).getTime() > cutoff);
  } catch (e) {
    return [];
  }
}

function saveTrash(trash) {
  localStorage.setItem(_trashKey(), JSON.stringify(trash));
}

function moveToTrash(receiptId) {
  const receipts = loadReceipts();
  const idx = receipts.findIndex(r => r.id === receiptId);
  if (idx === -1) return false;

  const [receipt] = receipts.splice(idx, 1);
  receipt.deletedAt = new Date().toISOString();

  const trash = loadTrash();
  trash.push(receipt);

  saveReceipts(receipts);
  saveTrash(trash);
  return true;
}

function restoreFromTrash(receiptId) {
  const trash = loadTrash();
  const idx = trash.findIndex(r => r.id === receiptId);
  if (idx === -1) return false;

  const [receipt] = trash.splice(idx, 1);
  delete receipt.deletedAt;

  saveTrash(trash);
  addReceipt(receipt);
  return true;
}

function permanentlyDelete(receiptId) {
  const trash = loadTrash().filter(r => r.id !== receiptId);
  saveTrash(trash);
}

function emptyTrash() {
  saveTrash([]);
}

// ═══════════════════════════════════════
// SAMPLE RECEIPTS (for seeding/testing)
// ═══════════════════════════════════════

// Used by "Use Sample Receipt" demo button.
// Replace / augment these to test different receipt scenarios.
const SAMPLE_RECEIPTS = [
  {
    id: 'sample-1',
    store: 'Safeway',
    date: '2026-06-05',
    total: 58.43,
    savedAt: new Date('2026-06-05').toISOString(),
    items: [
      { id: 'i1',  name: 'Bananas (bunch)',       price: 1.29,  category: 'groceries' },
      { id: 'i2',  name: 'Chicken Breast 2lb',    price: 7.99,  category: 'groceries' },
      { id: 'i3',  name: 'Whole Milk Gallon',     price: 4.49,  category: 'groceries' },
      { id: 'i4',  name: 'Sourdough Bread',       price: 3.99,  category: 'groceries' },
      { id: 'i5',  name: 'Head & Shoulders Shampoo', price: 6.79, category: 'personal-care' },
      { id: 'i6',  name: 'Bounty Paper Towels 6pk', price: 9.49, category: 'household' },
      { id: 'i7',  name: 'Dawn Dish Soap',        price: 3.29,  category: 'household' },
      { id: 'i8',  name: 'Starbucks Frappuccino', price: 3.69,  category: 'coffee' },
      { id: 'i9',  name: 'Pool Float Ring',       price: 8.99,  category: 'entertainment' },
      { id: 'i10', name: 'Tide Pods 16ct',        price: 7.99,  category: 'household' },
      { id: 'i11', name: 'Cheddar Cheese Block',  price: 4.49,  category: 'groceries' },
      { id: 'i12', name: 'Pasta Linguine 16oz',   price: 1.99,  category: 'groceries' },
    ]
  },
  {
    id: 'sample-2',
    store: 'Dutch Bros Coffee',
    date: '2026-06-03',
    total: 14.75,
    savedAt: new Date('2026-06-03').toISOString(),
    items: [
      { id: 'j1', name: 'Large Iced Americano',   price: 5.25, category: 'coffee' },
      { id: 'j2', name: 'Medium Freeze (Blended)', price: 5.75, category: 'coffee' },
      { id: 'j3', name: 'Sticker Pack',            price: 3.75, category: 'other' },
    ]
  },
  {
    id: 'sample-3',
    store: "Chipotle Mexican Grill",
    date: '2026-06-01',
    total: 22.80,
    savedAt: new Date('2026-06-01').toISOString(),
    items: [
      { id: 'k1', name: 'Burrito Bowl (Chicken)',  price: 10.40, category: 'eating-out' },
      { id: 'k2', name: 'Burrito (Steak)',         price: 10.95, category: 'eating-out' },
      { id: 'k3', name: 'Chips & Guacamole',       price: 4.45,  category: 'eating-out' },
    ]
  },
  {
    id: 'sample-4',
    store: "Fred Meyer",
    date: '2026-05-28',
    total: 91.14,
    savedAt: new Date('2026-05-28').toISOString(),
    items: [
      { id: 'l1',  name: 'Graphic Tee (2pk)',      price: 14.99, category: 'clothing' },
      { id: 'l2',  name: 'Athletic Socks 6pk',     price: 8.99,  category: 'clothing' },
      { id: 'l3',  name: 'Eggs Large 18ct',        price: 5.29,  category: 'groceries' },
      { id: 'l4',  name: 'Greek Yogurt 4pk',       price: 6.49,  category: 'groceries' },
      { id: 'l5',  name: 'Notebook College Ruled', price: 2.99,  category: 'school' },
      { id: 'l6',  name: 'Pens Ballpoint 12pk',    price: 4.49,  category: 'school' },
      { id: 'l7',  name: 'Febreze Air Freshener',  price: 4.99,  category: 'household' },
      { id: 'l8',  name: 'Colgate Toothpaste',     price: 3.49,  category: 'personal-care' },
      { id: 'l9',  name: 'Gillette Razor Refill',  price: 11.99, category: 'personal-care' },
      { id: 'l10', name: 'Lunchables (3pk)',        price: 8.49,  category: 'groceries' },
      { id: 'l11', name: 'Gatorade 8pk',            price: 9.99,  category: 'groceries' },
      { id: 'l12', name: 'Postmates Gift Card',     price: 20.00, category: 'other' },
    ]
  },
  {
    id: 'sample-5',
    store: "Chevron",
    date: '2026-05-25',
    total: 53.20,
    savedAt: new Date('2026-05-25').toISOString(),
    items: [
      { id: 'm1', name: 'Regular Unleaded (13.4gal)', price: 48.70, category: 'gas' },
      { id: 'm2', name: 'Sparkling Water 1L',         price: 2.50,  category: 'groceries' },
      { id: 'm3', name: 'Kind Bar Almond',             price: 2.00,  category: 'groceries' },
    ]
  },
];

// ═══════════════════════════════════════
// SEED SAMPLE DATA (run once)
// ═══════════════════════════════════════

// Uncomment to seed demo data on first load:
// function seedSampleData() {
//   if (!localStorage.getItem(STORAGE_KEY)) {
//     saveReceipts(SAMPLE_RECEIPTS);
//   }
// }
// seedSampleData();
