/**
 * ocr.js — Receipt scanning and AI categorization
 * 
 * This file contains TWO layers:
 * 
 * 1. parseReceiptWithAI(imageFile) — The main entry point.
 *    Currently uses the Anthropic API (Claude) via the
 *    in-artifact API bridge to do real vision-based OCR
 *    and smart per-item categorization.
 * 
 * 2. parseMockReceipt() — Returns hardcoded sample data.
 *    Used as fallback or for offline testing.
 * 
 * ─────────────────────────────────────────
 * TO ADD REAL SERVER-SIDE OCR:
 *   Replace the fetch call in parseReceiptWithAI() with
 *   your own backend endpoint, e.g.:
 *     POST /api/scan-receipt
 *     Body: FormData with the image
 *   Your backend can call a dedicated OCR service like:
 *     - Google Cloud Vision API
 *     - AWS Textract
 *     - Microsoft Azure Read API
 *   Then pass the extracted text to an LLM for structuring
 *   and categorization.
 * ─────────────────────────────────────────
 */

// ═══════════════════════════════════════
// REAL AI PARSING via Anthropic Vision API
// ═══════════════════════════════════════

async function parseReceiptWithAI(imageFile) {
  /**
   * Converts the uploaded image to base64 and sends it to
   * Claude claude-sonnet-4-20250514 with a structured extraction prompt.
   * 
   * Returns a receipt object:
   * {
   *   store: string,
   *   date: string (YYYY-MM-DD),
   *   total: number,
   *   items: [{ id, name, price, category }]
   * }
   */

  // Convert image to base64
  const base64Image = await fileToBase64(imageFile);
  const mediaType = imageFile.type || 'image/jpeg';

  const systemPrompt = `You are a receipt scanning and budgeting assistant. 
Your job is to extract structured data from receipt images and categorize EACH LINE ITEM individually.

CRITICAL RULE: Do NOT categorize by store name alone. Read every line item and categorize it based on what the item actually is.

Categories available:
- groceries: food items, fresh produce, meat, dairy, pantry staples, beverages
- eating-out: restaurant meals, fast food, prepared food purchased at a restaurant
- coffee: coffee drinks, tea, boba, smoothies, energy drinks
- household: cleaning supplies, paper products, light bulbs, storage, home decor
- personal-care: shampoo, soap, toothpaste, razors, makeup, skincare
- clothing: clothes, shoes, accessories, socks, underwear
- gas: fuel, car wash, automotive items
- entertainment: movies, games, toys, recreational gear, books (non-school), streaming cards
- school: notebooks, pens, textbooks, school supplies, educational materials
- other: gift cards, fees, unclassifiable items

Return ONLY valid JSON with this exact structure:
{
  "store": "Store Name",
  "date": "YYYY-MM-DD",
  "total": 00.00,
  "items": [
    { "name": "Item Name", "price": 0.00, "category": "category-id" }
  ]
}

If you cannot determine the date, use today's date. If you cannot read a price clearly, estimate based on context. Include ALL line items you can identify. Do not include tax lines as items.`;

  const userPrompt = `Please extract the receipt data from this image and return structured JSON.`;

  try {
    const response = await fetch('https://api.anthropic.com/v1/messages', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        model: 'claude-sonnet-4-20250514',
        max_tokens: 1500,
        system: systemPrompt,
        messages: [
          {
            role: 'user',
            content: [
              {
                type: 'image',
                source: {
                  type: 'base64',
                  media_type: mediaType,
                  data: base64Image,
                }
              },
              { type: 'text', text: userPrompt }
            ]
          }
        ]
      })
    });

    if (!response.ok) {
      const err = await response.json().catch(() => ({}));
      throw new Error(err.error?.message || `API error ${response.status}`);
    }

    const data = await response.json();
    const rawText = data.content
      .filter(b => b.type === 'text')
      .map(b => b.text)
      .join('');

    // Strip any markdown code fences if present
    const cleaned = rawText.replace(/```json|```/g, '').trim();
    const parsed = JSON.parse(cleaned);

    // Normalize and add IDs
    const items = (parsed.items || []).map((item, i) => ({
      id: `ai-${Date.now()}-${i}`,
      name: item.name || 'Unknown Item',
      price: parseFloat(item.price) || 0,
      category: item.category || 'other',
    }));

    return {
      store: parsed.store || 'Unknown Store',
      date: parsed.date || new Date().toISOString().split('T')[0],
      total: parseFloat(parsed.total) || items.reduce((s, i) => s + i.price, 0),
      items,
    };

  } catch (err) {
    console.error('AI parsing failed:', err);
    throw err;
  }
}

// ═══════════════════════════════════════
// MOCK RECEIPT (demo / offline fallback)
// ═══════════════════════════════════════

function parseMockReceipt() {
  /**
   * Returns a realistic sample Safeway receipt.
   * 
   * This demonstrates per-item categorization:
   * - The store is Safeway (a grocery store)
   * - But items span Groceries, Personal Care, Household,
   *   Coffee, and Entertainment categories.
   * 
   * In production, replace this with a real API call.
   */

  // Simulate a small random variation so demo feels "live"
  const variation = () => +(Math.random() * 0.4 - 0.2).toFixed(2);

  return {
    store: 'Safeway',
    date: new Date().toISOString().split('T')[0],
    total: 67.82,
    items: [
      // GROCERIES — food items from a grocery store
      { id: `m-${Date.now()}-1`,  name: 'Bananas (bunch)',          price: +(1.29 + variation()).toFixed(2), category: 'groceries' },
      { id: `m-${Date.now()}-2`,  name: 'Chicken Breast 2lb',       price: +(7.99 + variation()).toFixed(2), category: 'groceries' },
      { id: `m-${Date.now()}-3`,  name: 'Whole Milk Gallon',        price: +(4.49 + variation()).toFixed(2), category: 'groceries' },
      { id: `m-${Date.now()}-4`,  name: 'Sourdough Bread Loaf',     price: +(3.99 + variation()).toFixed(2), category: 'groceries' },
      { id: `m-${Date.now()}-5`,  name: 'Cheddar Cheese Block 8oz', price: +(4.49 + variation()).toFixed(2), category: 'groceries' },
      { id: `m-${Date.now()}-6`,  name: 'Roma Tomatoes (3lb bag)',  price: +(2.99 + variation()).toFixed(2), category: 'groceries' },

      // PERSONAL CARE — beauty/hygiene even though store is Safeway
      { id: `m-${Date.now()}-7`,  name: 'Head & Shoulders Shampoo', price: +(6.79 + variation()).toFixed(2), category: 'personal-care' },
      { id: `m-${Date.now()}-8`,  name: 'Colgate Total Toothpaste', price: +(3.49 + variation()).toFixed(2), category: 'personal-care' },

      // HOUSEHOLD — cleaning/paper products
      { id: `m-${Date.now()}-9`,  name: 'Bounty Paper Towels 6pk',  price: +(9.49 + variation()).toFixed(2), category: 'household' },
      { id: `m-${Date.now()}-10`, name: 'Dawn Dish Soap 19oz',      price: +(3.29 + variation()).toFixed(2), category: 'household' },

      // COFFEE/DRINKS — pre-packaged beverages
      { id: `m-${Date.now()}-11`, name: 'Starbucks Frappuccino Btl', price: +(3.69 + variation()).toFixed(2), category: 'coffee' },

      // ENTERTAINMENT — recreational item from a grocery store
      { id: `m-${Date.now()}-12`, name: 'Pool Float Ring',           price: +(8.99 + variation()).toFixed(2), category: 'entertainment' },
    ]
  };
}

// ═══════════════════════════════════════
// UTILITY
// ═══════════════════════════════════════

function fileToBase64(file) {
  return new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.onload = () => resolve(reader.result.split(',')[1]);
    reader.onerror = () => reject(new Error('Could not read image file'));
    reader.readAsDataURL(file);
  });
}

/**
 * Progress steps shown to the user during scanning.
 * These are displayed sequentially for UX — swap or extend
 * as your real OCR pipeline grows.
 */
const SCAN_STEPS = [
  'Uploading image...',
  'Detecting receipt edges...',
  'Reading line items...',
  'Identifying categories...',
  'Almost done...',
];
