SplitReceiptio Local Test Version

This version is ONLY for testing on your computer while Netlify deploys are paused.

What is different:
- Login is bypassed.
- It automatically signs in as "Local Test".
- Demo receipts still cannot save into your real budget.
- Real production Netlify Identity code is not active in this local-test zip.

How to test:
1. Unzip this folder.
2. Double-click index.html.
3. Go to Upload Receipt.
4. Click Use Sample Receipt.
5. Confirm that the review page says demo mode and the demo cannot be saved.
