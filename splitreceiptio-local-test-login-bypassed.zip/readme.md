# Ledger — Receipt Tracker MVP

A clean, modern budgeting app for college students and young adults. Upload receipt photos, let AI extract and categorize every item, then track monthly spending by category.

---

## Quick Start (No install needed)

This is a plain HTML/CSS/JS app. No build step, no npm, no framework.

**Option 1: Open directly**
```
double-click index.html
```

**Option 2: Local server (recommended — avoids browser file:// restrictions)**
```bash
# Python 3
python3 -m http.server 3000

# Node.js (if installed)
npx serve .

# Then open: http://localhost:3000
```

---

## Project Structure

```
receipt-tracker/
├── index.html          # All pages/screens (SPA with JS page switching)
├── css/
│   └── style.css       # All styles — tokens, layout, components
├── js/
│   ├── data.js         # Categories, localStorage helpers, sample data
│   ├── ocr.js          # AI parsing (Claude Vision API) + mock fallback
│   └── app.js          # App logic: nav, dashboard, upload, review, history
└── README.md
```

---

## Features

- **Upload a receipt image** (drag & drop or click)
- **AI extracts** store name, date, line items, prices, total
  - Uses Claude Vision API (`claude-sonnet-4-20250514`) for real OCR
  - Falls back to realistic mock data if API is unavailable
- **Per-item categorization** — each item gets its own category, not the whole receipt
- **Review screen** — confirm/edit categories per item, or "Confirm All"
- **Monthly dashboard** — total spent, top category, donut chart, category breakdown
- **Month filter** on dashboard and history pages
- **Receipt history** — full item list with category badges per receipt
- **Demo mode** — "Use Sample Receipt" button for instant testing

---

## AI Integration

The app uses the Anthropic API directly from the browser (no backend required) via the API bridge provided by the Claude.ai artifact environment.

**How it works:**
1. User uploads a receipt image
2. Image is converted to base64
3. Sent to `claude-sonnet-4-20250514` with a vision prompt
4. Claude returns structured JSON: store, date, total, items with categories
5. Items appear on the review screen

**To use with your own API key (running locally):**

In `js/ocr.js`, the `fetch` call to `https://api.anthropic.com/v1/messages` needs an API key header. Add:
```js
headers: {
  'Content-Type': 'application/json',
  'x-api-key': 'YOUR_API_KEY_HERE',
  'anthropic-version': '2023-06-01',
  'anthropic-dangerous-direct-browser-ipc': 'true', // required for browser calls
}
```

**To add a backend OCR service instead:**
Replace `parseReceiptWithAI()` in `ocr.js` with a `fetch` to your own server:
```js
const res = await fetch('/api/scan-receipt', {
  method: 'POST',
  body: formData  // FormData with the image
});
```
Your backend can call Google Cloud Vision, AWS Textract, or Azure Read API.

---

## Customizing Categories

Edit the `CATEGORIES` array in `js/data.js`:
```js
{ id: 'groceries', label: 'Groceries', color: '#4CAF85', emoji: '🛒' },
```

---

## Sample Data

`js/data.js` includes 5 sample receipts for testing (Safeway, Dutch Bros, Chipotle, Fred Meyer, Chevron). To seed the app with sample data on first load, uncomment the `seedSampleData()` call at the bottom of `data.js`.

---

## Browser Support

Chrome, Firefox, Safari, Edge (any modern browser). No IE support.
localStorage is used for persistence — data is per-browser.
